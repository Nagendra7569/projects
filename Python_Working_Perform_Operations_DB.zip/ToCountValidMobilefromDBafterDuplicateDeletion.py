import pandas as pd
from sqlalchemy import create_engine
import mysql.connector
from mysql.connector import Error
import re
from tqdm import tqdm  # type: ignore

def clean_mobile_number(number):
    """Standardize mobile number format"""
    if pd.isna(number) or number == '':
        return None
    cleaned = re.sub(r'\D', '', str(number))
    return cleaned[-10:] if len(cleaned) >= 10 else cleaned

def get_primary_key(cursor, table):
    """Get primary key column name for a table"""
    cursor.execute(f"SHOW KEYS FROM `{table}` WHERE Key_name = 'PRIMARY'")
    primary_key = cursor.fetchone()
    return primary_key[4] if primary_key else None

def find_mobile_columns(engine, cursor):
    """Find all tables with mobile number columns"""
    cursor.execute("SHOW TABLES")
    tables = [table[0] for table in cursor.fetchall()]
    
    mobile_tables = {}
     
     
    for table in tqdm(tables, desc="Scanning tables for mobile columns"):
        try:
            cursor.execute(f"SHOW COLUMNS FROM `{table}`")
            columns = [col[0] for col in cursor.fetchall()]
            mobile_cols = [col for col in columns if 'mobile' in col.lower() or 'phone' in col.lower()]
            
            if mobile_cols:
                pk = get_primary_key(cursor, table)
                if not pk:
                    cursor.execute(f"SHOW INDEX FROM `{table}` WHERE Non_unique = 0")
                    unique_cols = [idx[4] for idx in cursor.fetchall()]
                    pk = unique_cols[0] if unique_cols else None
                
                if pk:
                    mobile_tables[table] = {
                        'mobile_col': mobile_cols[0],
                        'pk_col': pk,
                        'processed': False
                    }
        except Exception as e:
            print(f"\nError scanning table {table}: {str(e)}")
    
    return mobile_tables

def process_duplicates(engine, connection, mobile_tables):
    """Process duplicates and return counts of remaining mobile numbers"""
    first_occurrences = {}
    total_cleared = 0
    remaining_counts = {}  # To store counts per table after cleanup

    # First pass: identify first occurrences
    print("\nIdentifying first occurrences...")
    for table in tqdm(mobile_tables.keys()):
        config = mobile_tables[table]
        mobile_col = config['mobile_col']
        pk_col = config['pk_col']
        
        try:
            query = f"SELECT `{pk_col}`, `{mobile_col}` FROM `{table}` WHERE `{mobile_col}` IS NOT NULL"
            df = pd.read_sql(query, engine)
            
            if not df.empty:
                df['cleaned_mobile'] = df[mobile_col].apply(clean_mobile_number)
                df = df[df['cleaned_mobile'].notna()]
                
                for _, row in df.iterrows():
                    mobile = row['cleaned_mobile']
                    if mobile not in first_occurrences:
                        first_occurrences[mobile] = {
                            'table': table,
                            'pk_col': pk_col,
                            'pk_value': row[pk_col]
                        }
        except Exception as e:
            print(f"\nError processing table {table}: {str(e)}")

    # Second pass: nullify duplicates
    print("\nClearing duplicates...")
    for table in tqdm(mobile_tables.keys()):
        config = mobile_tables[table]
        mobile_col = config['mobile_col']
        pk_col = config['pk_col']
        cursor = connection.cursor()
        
        try:
            query = f"SELECT `{pk_col}`, `{mobile_col}` FROM `{table}` WHERE `{mobile_col}` IS NOT NULL"
            df = pd.read_sql(query, engine)
            
            if not df.empty:
                df['cleaned_mobile'] = df[mobile_col].apply(clean_mobile_number)
                df = df[df['cleaned_mobile'].notna()]
                
                cleared_in_table = 0
                for _, row in df.iterrows():
                    mobile = row['cleaned_mobile']
                    first_occ = first_occurrences.get(mobile)
                    
                    if first_occ and (first_occ['table'] != table or first_occ['pk_value'] != row[pk_col]):
                        update_query = f"UPDATE `{table}` SET `{mobile_col}` = NULL WHERE `{pk_col}` = %s"
                        cursor.execute(update_query, (row[pk_col],))
                        cleared_in_table += 1
                
                total_cleared += cleared_in_table
                connection.commit()

                # Count remaining mobile numbers in this table
                count_query = f"SELECT COUNT(*) FROM `{table}` WHERE `{mobile_col}` IS NOT NULL"
                cursor.execute(count_query)
                remaining_counts[table] = cursor.fetchone()[0]

        except Exception as e:
            connection.rollback()
            print(f"\nError updating table {table}: {str(e)}")
        finally:
            cursor.close()
    
    return total_cleared, remaining_counts

def main():
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'alldata',
        'raise_on_warnings': True
    }

    try:
        engine = create_engine(
            f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@"
            f"{db_config['host']}/{db_config['database']}"
        )
        connection = mysql.connector.connect(**db_config)
        print("Database connection established!")
        
        mobile_tables = find_mobile_columns(engine, connection.cursor())
        
        if not mobile_tables:
            print("No tables with mobile number columns found!")
            return
        
        print(f"\nFound {len(mobile_tables)} tables with mobile number columns:")
        for table in mobile_tables:
            print(f"- {table} (column: {mobile_tables[table]['mobile_col']})")
        
        total_cleared, remaining_counts = process_duplicates(engine, connection, mobile_tables)
        
        print(f"\nTotal duplicates cleared: {total_cleared}")
        print("\nRemaining mobile number counts per table:")
        for table, count in remaining_counts.items():
            print(f"- {table}: {count} unique mobile(s)")
        
        total_unique = sum(remaining_counts.values())
        print(f"\nTOTAL UNIQUE MOBILE NUMBERS IN DATABASE: {total_unique}")

    except Error as e:
        print(f"\nDatabase Error: {e}")
    except Exception as e:
        print(f"\nGeneral Error: {e}")
    finally:
        if 'connection' in locals() and connection.is_connected():
            connection.close()
            print("\nDatabase connection closed.")

if __name__ == "__main__":
    main()