import pandas as pd
import re
from tkinter import *
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
import os
import sys
from pathlib import Path
import threading

class AdvancedMobileCleaner:
    def __init__(self, root):
        self.root = root
        self.setup_ui()

    def setup_ui(self):
        self.root.title("Advanced Mobile Cleaner (Multiple Files)")
        self.root.geometry("900x700")
        self.root.configure(bg="#f0f4f8")  # Light background for overall window

        # Style setup
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('TButton', font=('Arial', 10, 'bold'), padding=5, background='#4CAF50', foreground='white')
        self.style.map('TButton', background=[('active', '#45a049')])
        self.style.configure('TLabel', font=('Arial', 10), background="#f0f4f8")
        self.style.configure('Header.TLabel', font=('Arial', 12, 'bold'), background="#f0f4f8")
        self.style.configure('Progress.Horizontal.TProgressbar', troughcolor='#d3d3d3', background='#2196F3')

        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=BOTH, expand=True)
        main_frame.configure(style='TFrame')
        ttk.Style().configure('TFrame', background="#f0f4f8")

        # Input Files
        ttk.Label(main_frame, text="Input Files:", style='Header.TLabel').grid(row=0, column=0, sticky=W, pady=5)
        self.input_listbox = Listbox(main_frame, width=70, height=4, selectmode=MULTIPLE)
        self.input_listbox.grid(row=0, column=1, padx=5)
        ttk.Button(main_frame, text="Browse", command=self.browse_input).grid(row=0, column=2)

        # Output Directory
        ttk.Label(main_frame, text="Output Directory:", style='Header.TLabel').grid(row=1, column=0, sticky=W, pady=5)
        self.output_entry = ttk.Entry(main_frame, width=70)
        self.output_entry.grid(row=1, column=1, padx=5)
        ttk.Button(main_frame, text="Browse", command=self.browse_output).grid(row=1, column=2)

        # Mobile Column
        ttk.Label(main_frame, text="Mobile Column:", style='Header.TLabel').grid(row=2, column=0, sticky=W, pady=5)
        self.mobile_col_entry = ttk.Entry(main_frame, width=20)
        self.mobile_col_entry.grid(row=2, column=1, sticky=W, padx=5)
        self.mobile_col_entry.insert(0, "mobilenumber")

        # Strict validation checkbox
        self.strict_var = BooleanVar(value=True)
        ttk.Checkbutton(
            main_frame,
            text="Strict Validation (10-digit India numbers only)",
            variable=self.strict_var
        ).grid(row=3, column=1, sticky=W, pady=5)

        # Progress bar
        self.progress = ttk.Progressbar(main_frame, orient=HORIZONTAL, length=600, mode='determinate', style='Progress.Horizontal.TProgressbar')
        self.progress.grid(row=4, column=0, columnspan=3, pady=15)

        # Button to start processing
        self.process_btn = ttk.Button(
            main_frame,
            text="Clean & Validate Numbers",
            command=lambda: threading.Thread(target=self.process_files).start()
        )
        self.process_btn.grid(row=5, column=0, columnspan=3, pady=10)

        # Log output
        ttk.Label(main_frame, text="Processing Log:", style='Header.TLabel').grid(row=6, column=0, sticky=NW, pady=5)
        self.log_text = ScrolledText(main_frame, height=20, width=100, wrap=WORD, font=('Consolas', 9))
        self.log_text.grid(row=7, column=0, columnspan=3, pady=5)
        self.log_text.config(bg="#e0f7fa")

        # Redirect stdout/stderr
        sys.stdout = TextRedirector(self.log_text, "stdout")
        sys.stderr = TextRedirector(self.log_text, "stderr")

    def browse_input(self):
        filepaths = filedialog.askopenfilenames(
            title="Select CSV Files",
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if filepaths:
            self.input_listbox.delete(0, END)
            for filepath in filepaths:
                self.input_listbox.insert(END, filepath)

    def browse_output(self):
        dirpath = filedialog.askdirectory()
        if dirpath:
            self.output_entry.delete(0, END)
            self.output_entry.insert(0, dirpath)

    def clean_and_validate_mobile(self, number):
        """Robust cleaning and validation of mobile numbers."""
        try:
            if pd.isna(number) or not str(number).strip():
                return None

            original = str(number).strip()

            # Convert scientific notation to float, then to string
            try:
                float_num = float(original)
                if float_num.is_integer():
                    number_str = str(int(float_num))
                else:
                    number_str = str(float_num)
            except:
                number_str = original

            # Remove all non-digit characters
            cleaned = re.sub(r'[^\d]', '', number_str)

            # Handle longer numbers with country code (take last 10 digits)
            if len(cleaned) > 10:
                cleaned = cleaned[-10:]

            # Validate length and starting digit if strict validation is enabled
            if self.strict_var.get():
                if len(cleaned) == 10 and cleaned[0] in '6789':
                    return cleaned
                else:
                    return None
            else:
                # Lenient mode, just return cleaned number
                return cleaned if cleaned else None

        except Exception as e:
            print(f"Error cleaning '{original}': {str(e)}")
            return None

    def process_files(self):
        input_files = self.input_listbox.get(0, END)
        output_dir = self.output_entry.get()
        mobile_col = self.mobile_col_entry.get().strip()

        if not all([input_files, output_dir, mobile_col]):
            messagebox.showerror("Error", "All fields are required!")
            return

        self.process_btn.config(state=DISABLED)
        self.progress['value'] = 0
        self.log_text.delete(1.0, END)

        total_files = len(input_files)
        processed_files = 0

        os.makedirs(output_dir, exist_ok=True)

        summary = []

        for file_idx, input_path in enumerate(input_files, 1):
            filename = os.path.basename(input_path)
            print("="*50)
            print(f"Processing file {file_idx} of {total_files}: {filename}")
            print("="*50)

            try:
                df = self.read_with_fallback(input_path)
                self.progress['value'] = (file_idx / total_files) * 20

                if mobile_col not in df.columns:
                    available_cols = ", ".join(df.columns)
                    print(f"\nWARNING: Column '{mobile_col}' not found in {filename}. Available columns: {available_cols}")
                    continue

                print(f"\nFound {len(df)} records. Cleaning mobile numbers...")
                df[mobile_col] = df[mobile_col].apply(self.clean_and_validate_mobile)

                # Remove duplicates
                df = df.drop_duplicates(subset=[mobile_col])

                valid_count = df[mobile_col].notna().sum()
                invalid_count = len(df) - valid_count

                cleaned_df = df.dropna(subset=[mobile_col])
                base_name = Path(input_path).stem
                output_path = os.path.join(output_dir, f"{base_name}_cleaned.csv")
                cleaned_df.to_csv(output_path, index=False, encoding='utf-8')

                self.progress['value'] = 20 + (file_idx / total_files) * 80

                # Record summary
                summary.append({
                    'filename': filename,
                    'original': len(df),
                    'valid': valid_count,
                    'invalid': invalid_count,
                    'output': output_path
                })

                print("\n" + "="*50)
                print(f"File {file_idx} Complete!")
                print("="*50)
                print(f"\nOriginal records: {len(df)}")
                print(f"Valid mobile numbers: {valid_count}")
                print(f"Removed invalid/duplicate: {invalid_count}")
                print(f"\nSaved to: {output_path}")

                processed_files += 1

            except Exception as e:
                print(f"\nERROR processing {filename}: {str(e)}")
                continue

        self.progress['value'] = 100
        print("\n" + "="*50)
        print("BATCH PROCESSING COMPLETE")
        print("="*50)
        print(f"\nProcessed {processed_files} of {total_files} files")

        if summary:
            print("\nSummary by file:")
            for item in summary:
                print(f"\nFile: {item['filename']}")
                print(f"  Original: {item['original']}")
                print(f"  Valid: {item['valid']}")
                print(f"  Invalid: {item['invalid']}")
                print(f"  Saved to: {item['output']}")

        messagebox.showinfo("Success", f"Processed {processed_files} files.\nCheck logs for details.")
        self.process_btn.config(state=NORMAL)

    def read_with_fallback(self, filepath):
        encodings = ['utf-8', 'latin1', 'cp1252', 'ISO-8859-1']
        for enc in encodings:
            try:
                print(f"Trying encoding: {enc}")
                return pd.read_csv(filepath, encoding=enc, engine='python')
            except UnicodeDecodeError:
                continue
            except Exception as e:
                print(f"Error with {enc}: {str(e)}")
        raise ValueError("Failed to read CSV with all fallback encodings.")

class TextRedirector(object):
    def __init__(self, widget, tag="stdout"):
        self.widget = widget
        self.tag = tag

    def write(self, text):
        self.widget.configure(state="normal")
        self.widget.insert(END, text)
        self.widget.configure(state="disabled")
        self.widget.see(END)

    def flush(self):
        pass

if __name__ == "__main__":
    root = Tk()
    app = AdvancedMobileCleaner(root)
    root.mainloop()