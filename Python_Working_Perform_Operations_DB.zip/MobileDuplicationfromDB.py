import pandas as pd
from sqlalchemy import create_engine
import mysql.connector
from mysql.connector import Error
import re
from tqdm import tqdm # type: ignore

def clean_mobile_number(number):
    """Standardize mobile number format"""
    if pd.isna(number) or number == '':
        return None
    # Remove all non-digit characters
    cleaned = re.sub(r'\D', '', str(number))
    # Standardize to 10 digits (adjust based on your country's format)
    return cleaned[-10:] if len(cleaned) >= 10 else cleaned

def get_primary_key(cursor, table):
    """Get primary key column name for a table"""
    cursor.execute(f"SHOW KEYS FROM `{table}` WHERE Key_name = 'PRIMARY'")
    primary_key = cursor.fetchone()
    return primary_key[4] if primary_key else None

def find_mobile_columns(engine, cursor):
    """Find all tables with mobile number columns"""
    cursor.execute("SHOW TABLES")
    tables = [table[0] for table in cursor.fetchall()]
    
    mobile_tables = {}
    
    for table in tqdm(tables, desc="Scanning tables for mobile columns"):
        try:
            # Get column info
            cursor.execute(f"SHOW COLUMNS FROM `{table}`")
            columns = [col[0] for col in cursor.fetchall()]
            
            # Find mobile-like columns (case insensitive)
            mobile_cols = [col for col in columns if 'mobile' in col.lower() or 'phone' in col.lower()]
            
            if mobile_cols:
                pk = get_primary_key(cursor, table)
                if not pk:
                    # Try to find a unique column
                    cursor.execute(f"SHOW INDEX FROM `{table}` WHERE Non_unique = 0")
                    unique_cols = [idx[4] for idx in cursor.fetchall()]
                    pk = unique_cols[0] if unique_cols else None
                
                if pk:
                    mobile_tables[table] = {
                        'mobile_col': mobile_cols[0],
                        'pk_col': pk,
                        'processed': False
                    }
        except Exception as e:
            print(f"\nError scanning table {table}: {str(e)}")
    
    return mobile_tables

def process_duplicates(engine, connection, mobile_tables):
    """Process all tables to nullify duplicate mobile numbers (keeping first occurrence)"""
    # First pass: identify all unique mobile numbers and their first occurrence
    first_occurrences = {}
    
    print("\nIdentifying first occurrences of all mobile numbers...")
    for table in tqdm(mobile_tables.keys()):
        config = mobile_tables[table]
        mobile_col = config['mobile_col']
        pk_col = config['pk_col']
        
        try:
            # Fetch all mobile numbers in this table
            query = f"SELECT `{pk_col}`, `{mobile_col}` FROM `{table}` WHERE `{mobile_col}` IS NOT NULL"
            df = pd.read_sql(query, engine)
            
            if not df.empty:
                # Clean mobile numbers
                df['cleaned_mobile'] = df[mobile_col].apply(clean_mobile_number)
                df = df[df['cleaned_mobile'].notna()]
                
                # For each mobile number, record if it's the first time we've seen it
                for _, row in df.iterrows():
                    mobile = row['cleaned_mobile']
                    if mobile not in first_occurrences:
                        first_occurrences[mobile] = {
                            'table': table,
                            'pk_col': pk_col,
                            'pk_value': row[pk_col]
                        }
        except Exception as e:
            print(f"\nError processing table {table}: {str(e)}")
    
    # Second pass: nullify duplicates (set mobile number to NULL)
    print("\nClearing duplicate mobile numbers...")
    total_cleared = 0
    
    for table in tqdm(mobile_tables.keys()):
        config = mobile_tables[table]
        mobile_col = config['mobile_col']
        pk_col = config['pk_col']
        
        try:
            cursor = connection.cursor()
            
            # Fetch all mobile numbers in this table
            query = f"SELECT `{pk_col}`, `{mobile_col}` FROM `{table}` WHERE `{mobile_col}` IS NOT NULL"
            df = pd.read_sql(query, engine)
            
            if not df.empty:
                # Clean mobile numbers
                df['cleaned_mobile'] = df[mobile_col].apply(clean_mobile_number)
                df = df[df['cleaned_mobile'].notna()]
                
                # Find duplicates to nullify
                for _, row in df.iterrows():
                    mobile = row['cleaned_mobile']
                    first_occ = first_occurrences.get(mobile)
                    
                    # If this isn't the first occurrence, nullify it
                    if first_occ and (first_occ['table'] != table or first_occ['pk_value'] != row[pk_col]):
                        update_query = f"""
                            UPDATE `{table}` 
                            SET `{mobile_col}` = NULL 
                            WHERE `{pk_col}` = %s
                        """
                        cursor.execute(update_query, (row[pk_col],))
                        total_cleared += 1
                
                connection.commit()
        except Exception as e:
            connection.rollback()
            print(f"\nError updating table {table}: {str(e)}")
        finally:
            cursor.close()
    
    return total_cleared

def main():
    # Database configuration
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'duplication_removal',
        'raise_on_warnings': True
    }

    try:
        # Create SQLAlchemy engine
        engine = create_engine(
            f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@"
            f"{db_config['host']}/{db_config['database']}"
        )
        
        # Establish direct connection
        connection = mysql.connector.connect(**db_config)
        print("Database connection established successfully!")
        
        # Find all tables with mobile number columns
        mobile_tables = find_mobile_columns(engine, connection.cursor())
        
        if not mobile_tables:
            print("No tables with mobile number columns found!")
            return
        
        print(f"\nFound {len(mobile_tables)} tables with mobile number columns:")
        for table in mobile_tables:
            print(f"- {table} (column: {mobile_tables[table]['mobile_col']})")
        
        # Process duplicates
        total_cleared = process_duplicates(engine, connection, mobile_tables)
        
        print(f"\nOperation complete! Total duplicate mobile numbers cleared: {total_cleared}")
        
    except Error as e:
        print(f"\nDatabase Error: {e}")
    except Exception as e:
        print(f"\nGeneral Error: {e}")
    finally:
        if 'connection' in locals() and connection.is_connected():
            connection.close()
            print("\nDatabase connection closed.")

if __name__ == "__main__":
    main()
     