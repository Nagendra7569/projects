import pandas as pd
import re
import os
import sys

def clean_mobile_number(number):
    """Robust mobile number cleaner with all edge cases handled"""
    try:
        # Handle empty/NA values
        if pd.isna(number) or str(number).strip() == '':
            return None
            
        # Convert to string and handle scientific notation
        num_str = str(number)
        if 'E' in num_str.upper():
            try:
                num_str = "{:.0f}".format(float(number))
            except:
                pass
            
        # Remove all non-digit characters
        cleaned = re.sub(r'[^\d]', '', num_str)
        
        # Extract last 10 digits if longer (handles country codes)
        cleaned = cleaned[-10:] if len(cleaned) >= 10 else None
        
        # Validate Indian mobile format (10 digits starting with 6-9)
        if cleaned and len(cleaned) == 10 and cleaned[0] in '6789':
            return cleaned
        return None
    except Exception as e:
        print(f"Warning: Error cleaning '{number}': {str(e)}", file=sys.stderr)
        return None

def read_csv_with_fallback(file_path):
    """Try multiple encodings to read the CSV file"""
    encodings = ['utf-8', 'latin1', 'cp1252', 'ISO-8859-1']
    
    for encoding in encodings:
        try:
            print(f"Trying encoding: {encoding}")
            return pd.read_csv(file_path, encoding=encoding, engine='python')
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"Error with {encoding}: {str(e)}", file=sys.stderr)
            continue
    
    raise ValueError(f"Failed to read {file_path} with any of {encodings}")

def process_csv(input_path, output_path):
    """Main processing function with complete error handling"""
    try:
        print(f"\nStarting processing: {os.path.abspath(input_path)}")
        
        # Read CSV with encoding fallback
        df = read_csv_with_fallback(input_path)
        print(f"Successfully read {len(df)} records")
        
        # Verify required column exists
        if 'mobilenumber' not in df.columns:
            available = ', '.join(df.columns)
            raise KeyError(f"'mobilenumber' column not found. Available columns: {available}")
        
        # Clean mobile numbers
        df['mobilenumber'] = df['mobilenumber'].apply(clean_mobile_number)
        
        # Initialize list to hold indices of rows to delete
        rows_to_delete = []
        seen_numbers = set()
        
        # Identify invalid or duplicate numbers
        for idx, mobile in df['mobilenumber'].items():
            if pd.isna(mobile):
                # Mark for deletion
                rows_to_delete.append(idx)
            else:
                if mobile in seen_numbers:
                    # Duplicate found, mark for deletion
                    rows_to_delete.append(idx)
                else:
                    seen_numbers.add(mobile)

        # Drop the rows with invalid or duplicate mobile numbers
        df.drop(index=rows_to_delete, inplace=True)

        # Save cleaned data
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        df.to_csv(output_path, index=False, encoding='utf-8')

        # Generate report
        total_rows = len(df) + len(rows_to_delete)
        remaining_rows = len(df)
        removed_rows = len(rows_to_delete)

        print("\n=== Processing Report ===")
        print(f"Total records processed: {total_rows}")
        print(f"Remaining valid mobile numbers: {remaining_rows}")
        print(f"Removed (invalid/duplicate/blank): {removed_rows}")
        print(f"Output saved to: {os.path.abspath(output_path)}")
        
        return True
    
    except Exception as e:
        print(f"\nFATAL ERROR: {str(e)}", file=sys.stderr)
        print("\nTroubleshooting steps:", file=sys.stderr)
        print("1. Verify the input file exists and is accessible", file=sys.stderr)
        print("2. Check the file has a 'mobilenumber' column", file=sys.stderr)
        print("3. Try opening/saving the file in Excel as UTF-8 CSV", file=sys.stderr)
        print("4. Inspect file for corruption using a text editor", file=sys.stderr)
        return False

# Configuration
input_csv = r"D:\Leads_HareKrishna\From_Bhushan\Domain_complete\Database-2024\52. Engineers Database\73. Home, Garden Pets Suppliers Database\Home, Garden & Pets 28890.csv"  # Set your actual input file path here
output_csv = r"D:\Leads_HareKrishna\From_Bhushan\Domain_complete\Database-2024\52. Engineers Database\73. Home, Garden Pets Suppliers Database\Home, Garden & Pets 28890.csv"  # Set your desired output file path here

# Main execution
if __name__ == "__main__":
    success = process_csv(input_csv, output_csv)
    
    # Final verification
    if success and os.path.exists(output_csv):
        print("\nVerification successful! Output file created:")
        print(f"Size: {os.path.getsize(output_csv)/1024:.2f} KB")
        print(f"Location: {os.path.abspath(output_csv)}")
    else:
        print("\nProcessing failed. Please check error messages above.", file=sys.stderr)