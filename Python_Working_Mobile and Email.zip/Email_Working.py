import pandas as pd
import re
import os
import sys
from tkinter import *
from tkinter import filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

class AdvancedEmailCleaner:
    def __init__(self, root):
        self.root = root
        self.input_files = []  # To store list of input files
        self.setup_ui()

    def setup_ui(self):
        self.root.title("Advanced Email Cleaner")
        self.root.geometry("900x750")
        self.root.configure(bg="#f0f4f8")

        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure('TButton', font=('Arial', 10, 'bold'), padding=5, background='#4CAF50', foreground='white')
        self.style.map('TButton', background=[('active', '#45a049')])
        self.style.configure('TLabel', font=('Arial', 10), background="#f0f4f8")
        self.style.configure('Header.TLabel', font=('Arial', 12, 'bold'), background="#f0f4f8")
        self.style.configure('Progress.Horizontal.TProgressbar', troughcolor='#d3d3d3', bordercolor='#d3d3d3', background='#2196F3')

        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=BOTH, expand=True)
        main_frame_style = ttk.Style()
        main_frame_style.configure('TFrame', background="#f0f4f8")

        # Input files
        ttk.Label(main_frame, text="Input CSV Files:", style='Header.TLabel').grid(row=0, column=0, sticky=W, pady=5)
        self.input_entry = ttk.Entry(main_frame, width=70)
        self.input_entry.grid(row=0, column=1, padx=5)
        ttk.Button(main_frame, text="Browse Files", command=self.browse_input_files).grid(row=0, column=2)

        # Output directory
        ttk.Label(main_frame, text="Output Directory:", style='Header.TLabel').grid(row=1, column=0, sticky=W, pady=5)
        self.output_dir_entry = ttk.Entry(main_frame, width=70)
        self.output_dir_entry.grid(row=1, column=1, padx=5)
        ttk.Button(main_frame, text="Browse", command=self.browse_output_dir).grid(row=1, column=2)

        # Email column
        ttk.Label(main_frame, text="Email Column:", style='Header.TLabel').grid(row=2, column=0, sticky=W, pady=5)
        self.email_col_entry = ttk.Entry(main_frame, width=20)
        self.email_col_entry.grid(row=2, column=1, sticky=W, padx=5)
        self.email_col_entry.insert(0, "email")

        # Options
        options_frame = ttk.Frame(main_frame)
        options_frame.grid(row=3, column=0, columnspan=3, sticky=W, pady=10)

        self.extract_first_var = BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Extract first email from lists", variable=self.extract_first_var).pack(side=LEFT, padx=5)

        self.remove_duplicates_var = BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Remove duplicate emails (clear cells)", variable=self.remove_duplicates_var).pack(side=LEFT, padx=5)

        self.strict_validation_var = BooleanVar(value=True)
        ttk.Checkbutton(options_frame, text="Strict email validation", variable=self.strict_validation_var).pack(side=LEFT, padx=5)

        # Progress bar
        self.progress = ttk.Progressbar(main_frame, orient=HORIZONTAL, length=600, mode='determinate', style='Progress.Horizontal.TProgressbar')
        self.progress.grid(row=4, column=0, columnspan=3, pady=15)

        # Process button
        self.process_btn = ttk.Button(main_frame, text="Clean & Validate Emails", command=self.process_files)
        self.process_btn.grid(row=5, column=0, columnspan=3, pady=10)

        # Log Text
        ttk.Label(main_frame, text="Processing Log:", style='Header.TLabel').grid(row=6, column=0, sticky=NW, pady=5)
        self.log_text = ScrolledText(main_frame, height=20, width=100, wrap=WORD, font=('Consolas', 9))
        self.log_text.grid(row=7, column=0, columnspan=3, pady=5)
        self.log_text.config(bg="#e0f7fa")

        # Redirect stdout and stderr to log
        sys.stdout = TextRedirector(self.log_text, "stdout")
        sys.stderr = TextRedirector(self.log_text, "stderr")

    def browse_input_files(self):
        files = filedialog.askopenfilenames(filetypes=[("CSV Files", "*.csv")])
        if files:
            self.input_files = list(files)
            # Show comma-separated list in entry
            self.input_entry.delete(0, END)
            self.input_entry.insert(0, "; ".join(files))
            # Set default output directory as first input's directory
            first_dir = os.path.dirname(files[0])
            self.output_dir_entry.delete(0, END)
            self.output_dir_entry.insert(0, first_dir)

    def browse_output_dir(self):
        directory = filedialog.askdirectory()
        if directory:
            self.output_dir_entry.delete(0, END)
            self.output_dir_entry.insert(0, directory)

    def clean_email(self, email):
        if pd.isna(email) or not str(email).strip():
            return None

        original = str(email).strip()
        email_str = original.lower()

        if self.extract_first_var.get():
            email_str = email_str.split(',')[0].strip()

        # Remove unwanted characters
        email_str = re.sub(r'[{}<>\[\]()\"\']', '', email_str)

        if self.strict_validation_var.get():
            email_regex = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
            if not re.match(email_regex, email_str):
                return ''
            if len(email_str) > 254 or '..' in email_str:
                return ''

        return email_str

    def read_with_fallback(self, filepath):
        encodings = ['utf-8', 'latin1', 'cp1252', 'ISO-8859-1']
        for encoding in encodings:
            try:
                print(f"Trying encoding: {encoding}")
                return pd.read_csv(filepath, encoding=encoding, engine='python')
            except UnicodeDecodeError:
                continue
            except Exception as e:
                print(f"Error with {encoding}: {str(e)}")
                continue
        raise ValueError(f"Failed to read file with any encoding: {encodings}")

    def process_files(self):
        if not self.input_files:
            messagebox.showerror("Error", "Please select input files.")
            return
        output_dir = self.output_dir_entry.get().strip()
        email_col = self.email_col_entry.get().strip()

        if not output_dir:
            messagebox.showerror("Error", "Please select an output directory.")
            return

        self.process_btn.config(state=DISABLED)
        self.progress['value'] = 0
        self.log_text.delete(1.0, END)

        total_files = len(self.input_files)
        for idx, input_path in enumerate(self.input_files):
            try:
                print("=" * 50)
                print(f"Processing: {os.path.basename(input_path)}")
                print("=" * 50)

                df = self.read_with_fallback(input_path)

                # Find matching email column (case-insensitive)
                matching_cols = [col for col in df.columns if col.strip().lower() == email_col.lower()]
                if not matching_cols:
                    available = ", ".join(df.columns)
                    raise ValueError(f"Column '{email_col}' not found. Available columns: {available}")
                email_column_name = matching_cols[0]

                print(f"\nFound {len(df)} records. Cleaning emails...")

                df[email_column_name] = df[email_column_name].apply(self.clean_email)
                # Remove duplicates if selected
                if self.remove_duplicates_var.get():
                    duplicate_mask = df.duplicated(subset=[email_column_name], keep='first')
                    df.loc[duplicate_mask, email_column_name] = ''
                    print(f"\nFound {duplicate_mask.sum()} duplicate emails (cleared emails).")

                # Save output file
                filename = os.path.basename(input_path)
                output_path = os.path.join(output_dir, filename)
                os.makedirs(output_dir, exist_ok=True)
                df.to_csv(output_path, index=False, encoding='utf-8')

                print(f"\nSaved cleaned file: {output_path}")
                print(f"Progress: {idx + 1}/{total_files}")
            except Exception as e:
                print(f"\nError processing {input_path}: {str(e)}")
            self.progress['value'] = ((idx + 1) / total_files) * 100

        self.progress['value'] = 100
        messagebox.showinfo("Done", f"Processed {total_files} files.")
        self.process_btn.config(state=NORMAL)

class TextRedirector:
    def __init__(self, widget, tag="stdout"):
        self.widget = widget
        self.tag = tag

    def write(self, text):
        self.widget.configure(state="normal")
        self.widget.insert(END, text)
        self.widget.configure(state="disabled")
        self.widget.see(END)

    def flush(self):
        pass

if __name__ == "__main__":
    root = Tk()
    app = AdvancedEmailCleaner(root)
    root.mainloop()