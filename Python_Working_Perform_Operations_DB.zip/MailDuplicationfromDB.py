import pandas as pd
from sqlalchemy import create_engine
import mysql.connector
from mysql.connector import Error
import re
from tqdm import tqdm # type: ignore

def clean_email(email):
    """Standardize email format"""
    if pd.isna(email) or email == '':
        return None
    return str(email).strip().lower()

def get_primary_key(cursor, table):
    """Get primary key column name for a table"""
    cursor.execute(f"SHOW KEYS FROM `{table}` WHERE Key_name = 'PRIMARY'")
    primary_key = cursor.fetchone()
    return primary_key[4] if primary_key else None

def find_email_columns(engine, cursor):
    """Find all tables with email columns"""
    cursor.execute("SHOW TABLES")
    tables = [table[0] for table in cursor.fetchall()]
    
    email_tables = {}
    
    for table in tqdm(tables, desc="Scanning tables for email columns"):
        try:
            cursor.execute(f"SHOW COLUMNS FROM `{table}`")
            columns = [col[0] for col in cursor.fetchall()]
            
            # Look for email-like columns
            email_cols = [col for col in columns if 'email' in col.lower()]
            
            if email_cols:
                pk = get_primary_key(cursor, table)
                if not pk:
                    cursor.execute(f"SHOW INDEX FROM `{table}` WHERE Non_unique = 0")
                    unique_cols = [idx[4] for idx in cursor.fetchall()]
                    pk = unique_cols[0] if unique_cols else None
                
                if pk:
                    email_tables[table] = {
                        'email_col': email_cols[0],
                        'pk_col': pk,
                        'processed': False
                    }
        except Exception as e:
            print(f"\nError scanning table {table}: {str(e)}")
    
    return email_tables

def process_email_duplicates(engine, connection, email_tables):
    """Process all tables to nullify duplicate emails (keeping first occurrence)"""
    first_occurrences = {}
    
    print("\nIdentifying first occurrences of all email addresses...")
    for table in tqdm(email_tables.keys()):
        config = email_tables[table]
        email_col = config['email_col']
        pk_col = config['pk_col']
        
        try:
            query = f"SELECT `{pk_col}`, `{email_col}` FROM `{table}` WHERE `{email_col}` IS NOT NULL"
            df = pd.read_sql(query, engine)
            
            if not df.empty:
                df['cleaned_email'] = df[email_col].apply(clean_email)
                df = df[df['cleaned_email'].notna()]
                
                for _, row in df.iterrows():
                    email = row['cleaned_email']
                    if email not in first_occurrences:
                        first_occurrences[email] = {
                            'table': table,
                            'pk_col': pk_col,
                            'pk_value': row[pk_col]
                        }
        except Exception as e:
            print(f"\nError processing table {table}: {str(e)}")
    
    print("\nClearing duplicate email addresses...")
    total_cleared = 0
    
    for table in tqdm(email_tables.keys()):
        config = email_tables[table]
        email_col = config['email_col']
        pk_col = config['pk_col']
        
        try:
            cursor = connection.cursor()
            query = f"SELECT `{pk_col}`, `{email_col}` FROM `{table}` WHERE `{email_col}` IS NOT NULL"
            df = pd.read_sql(query, engine)
            
            if not df.empty:
                df['cleaned_email'] = df[email_col].apply(clean_email)
                df = df[df['cleaned_email'].notna()]
                
                for _, row in df.iterrows():
                    email = row['cleaned_email']
                    first_occ = first_occurrences.get(email)
                    
                    if first_occ and (first_occ['table'] != table or first_occ['pk_value'] != row[pk_col]):
                        update_query = f"""
                            UPDATE `{table}` 
                            SET `{email_col}` = NULL 
                            WHERE `{pk_col}` = %s
                        """
                        cursor.execute(update_query, (row[pk_col],))
                        total_cleared += 1
                
                connection.commit()
        except Exception as e:
            connection.rollback()
            print(f"\nError updating table {table}: {str(e)}")
        finally:
            cursor.close()
    
    return total_cleared

def main():
    db_config = {
        'host': 'localhost',
        'user': 'root',
        'password': '',
        'database': 'duplication_removal',
        'raise_on_warnings': True
    }

    try:
        engine = create_engine(
            f"mysql+mysqlconnector://{db_config['user']}:{db_config['password']}@"
            f"{db_config['host']}/{db_config['database']}"
        )
        
        connection = mysql.connector.connect(**db_config)
        print("Database connection established successfully!")
        
        email_tables = find_email_columns(engine, connection.cursor())
        
        if not email_tables:
            print("No tables with email columns found!")
            return
        
        print(f"\nFound {len(email_tables)} tables with email columns:")
        for table in email_tables:
            print(f"- {table} (column: {email_tables[table]['email_col']})")
        
        total_cleared = process_email_duplicates(engine, connection, email_tables)
        
        print(f"\nOperation complete! Total duplicate emails cleared: {total_cleared}")
        
    except Error as e:
        print(f"\nDatabase Error: {e}")
    except Exception as e:
        print(f"\nGeneral Error: {e}")
    finally:
        if 'connection' in locals() and connection.is_connected():
            connection.close()
            print("\nDatabase connection closed.")

if __name__ == "__main__":
    main()
